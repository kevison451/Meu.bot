import time
import random
import json
import telebot
from datetime import datetime
from telebot.types import InlineKeyboardButton, InlineKeyboardMarkup
import bd
import pytz

api_key = ''   #7846006314:AAHIxg0BGbVNQT7TuOuqSTwsgura22L_S8s"
chat_id = ''  #7464240933"

bot = telebot.TeleBot(token=api_key)

# Defina as funções ALERT_GALE1 e DELETE_GALE1 como antes
def ALERT_GALE1():
    h = datetime.now().hour
    m = datetime.now().minute + 1
    s = datetime.now().second
    if h <= 9:
        h = f'0{h}'
    if m <= 9:
        m = f'0{m}'
    if s <= 9:
        s = f'0{s}'
    message_id = bot.send_message(chat_id=chat_id, text=f'''
🔍 Possivel Entrada Detectada''').message_id
    bd.message_ids1 = message_id
    time.sleep(15)
    bd.message_delete1 = True

def DELETE_GALE1():
    if bd.message_delete1 == True:
        bot.delete_message(chat_id=chat_id, message_id=bd.message_ids1)
        bd.message_delete1 = False

# Resto do código
def button_link():
    markup = InlineKeyboardMarkup()
    markup.row_width = 2
    markup.add(InlineKeyboardButton(text="📲 Cadastre-se Agora", url="https://www.brganhar99.com/m/index.html"))
    return markup


ALERT_GALE1()

def random_exit_value():
    return round(random.uniform(1.10, 2.50), 2)

def send_alert_message():
    exit_value = random_exit_value()
    message = f"🤑 ENTRADA CONFIRMADA\n🚀 Jogo: Aviator - Oficial\n👉 Sair em: {exit_value}\n🧠 Fazer até 2 martingales"
    bot.send_message(chat_id=chat_id, text=message, reply_markup=button_link())

def send_green_message():
    bot.send.message(chat_id=chat_id, text="✅ GREEN ✅")

while True:
    portugal_tz = pytz.timezone('Europe/Lisbon')
    current_time = datetime.now(portugal_tz)
    h = current_time.hour
    m = current_time.minute + 4
    s = current_time.second
    if h <= 9:
        h = f'0{h}'
    if m <= 9:
        m = f'0{m}'
    if s <= 9:
        s = f'0{s}'
    print(f'{h}:{m}:{s}')
    formatted_time = current_time.strftime('%H:%M:%S')
    print(formatted_time)

    # Enviar a mensagem no canal com valor aleatório
    send_alert_message()

    time.sleep(60)
    time.sleep(60)
    time.sleep(60)

    send_green_message()